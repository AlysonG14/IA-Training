# Restaurant > Restaurant
https://universe.roboflow.com/training-ia-facial-recognition/restaurant-4ho7j

Provided by a Roboflow user
License: CC BY 4.0

